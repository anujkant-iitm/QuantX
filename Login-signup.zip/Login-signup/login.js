// login.js
import { auth } from './firebase-config.js';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";

// DOM Elements
const form = document.getElementById('auth-form');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const errorMessage = document.getElementById('error-message');
const googleLoginBtn = document.getElementById('google-login-btn');

// Handle Email/Password Signup or Login
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = emailInput.value;
    const password = passwordInput.value;

    try {
        // Try to sign in
        await signInWithEmailAndPassword(auth, email, password);
        alert('Logged in successfully');
        // Redirect or do something next
    } catch (signInError) {
        if (signInError.code === 'auth/user-not-found') {
            // If user doesn't exist, create new account
            try {
                await createUserWithEmailAndPassword(auth, email, password);
                alert('Account created and logged in!');
                // Redirect or do something next
            } catch (signupError) {
                errorMessage.textContent = signupError.message;
            }
        } else {
            errorMessage.textContent = signInError.message;
        }
    }
});

// Google Login
googleLoginBtn.addEventListener('click', async () => {
    const provider = new GoogleAuthProvider();

    try {
        const result = await signInWithPopup(auth, provider);
        const user = result.user;
        alert(`Logged in as ${user.email}`);
        // Do something next
    } catch (error) {
        console.error('Google login failed:', error);
        alert(error.message);
    }
});